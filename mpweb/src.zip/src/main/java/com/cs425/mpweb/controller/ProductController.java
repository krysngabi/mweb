package com.cs425.mpweb.controller;

import com.cs425.mpweb.model.Product;
import com.cs425.mpweb.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

@Controller
public class ProductController {
	
	@Autowired
	private ProductService productService;

	@RequestMapping(value="/mweb/products", method = RequestMethod.GET)
	public ModelAndView students(){
		List<Product> products = productService.findAll();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("products", products);
		modelAndView.setViewName("product/list");
		return modelAndView;
	}
	
	@RequestMapping(value="/mweb/product", method = RequestMethod.GET)
	public String create(Model model){
		model.addAttribute("product", new Product());
		return "product/edit";
	}
	
	@RequestMapping(value = "/mweb/product", method = RequestMethod.POST)
	public String edit(@Valid @ModelAttribute("product") Product product,
                       BindingResult result, Model model)  {

		if (result.hasErrors()) {
			System.out.println(result.getAllErrors());
			model.addAttribute("errors", result.getAllErrors());
			return "product/edit";
		}
        product = productService.save(product);
		return "redirect:/mweb/products";
	}	
	
	@RequestMapping(value="/mweb/product/{id}", method = RequestMethod.GET)
	public String view(@PathVariable Long id, Model model){
		model.addAttribute("pr", productService.findOne(id));
		return "product/edit";
	}
	
	@RequestMapping(value="/mweb/product/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable Long id, Model model){
        productService.delete(id);
		return "redirect:/mweb/products";
	}	
}
